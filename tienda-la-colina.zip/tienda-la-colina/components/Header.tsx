"use client";

import Link from "next/link";
import { useCarrito } from "@/context/CartContext";

export default function Header() {
  const { totalArticulos } = useCarrito();

  return (
    <header className="sticky top-0 z-50 bg-crema/85 backdrop-blur-md border-b border-verde/10">
      <div className="mx-auto max-w-5xl px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <span className="grid place-items-center w-9 h-9 rounded-xl bg-verde text-white font-display font-extrabold">
            LC
          </span>
          <div className="leading-none">
            <p className="font-display font-extrabold text-lg text-verde-oscuro">
              La Colina
            </p>
            <p className="text-[11px] text-verde font-semibold -mt-0.5">
              Entrega en 5 min
            </p>
          </div>
        </Link>

        <Link
          href="/carrito"
          className="relative grid place-items-center w-11 h-11 rounded-xl bg-white shadow-suave active:scale-95 transition"
          aria-label="Ver carrito"
        >
          <span className="text-xl">🛒</span>
          {totalArticulos > 0 && (
            <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 grid place-items-center rounded-full bg-naranja text-white text-xs font-bold">
              {totalArticulos}
            </span>
          )}
        </Link>
      </div>
    </header>
  );
}
