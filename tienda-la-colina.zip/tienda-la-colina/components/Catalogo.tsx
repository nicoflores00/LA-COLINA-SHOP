"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { PRODUCTOS, CATEGORIAS, moneda } from "@/lib/productos";
import { useCarrito } from "@/context/CartContext";
import ProductCard from "./ProductCard";

const TABS = ["Todos", ...CATEGORIAS] as const;

export default function Catalogo() {
  const [activa, setActiva] = useState<string>("Todos");
  const { totalArticulos, totalPrecio } = useCarrito();

  const productos = useMemo(
    () =>
      activa === "Todos"
        ? PRODUCTOS
        : PRODUCTOS.filter((p) => p.categoria === activa),
    [activa]
  );

  return (
    <section className="mx-auto max-w-5xl px-4 mt-6">
      {/* Filtros de categoría */}
      <div className="sticky top-16 z-40 -mx-4 px-4 py-3 bg-crema/90 backdrop-blur">
        <div className="flex gap-2 overflow-x-auto sin-scroll">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setActiva(t)}
              className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-semibold transition ${
                activa === t
                  ? "bg-verde text-white shadow-suave"
                  : "bg-white text-tinta/70 hover:text-tinta"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Grid de productos */}
      <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
        {productos.map((p) => (
          <ProductCard key={p.id} producto={p} />
        ))}
      </div>

      {/* Barra flotante del carrito */}
      {totalArticulos > 0 && (
        <Link
          href="/carrito"
          className="fixed inset-x-0 bottom-0 z-50 animate-subir"
        >
          <div className="mx-auto max-w-5xl px-4 pb-4">
            <div className="flex items-center justify-between rounded-2xl bg-verde-oscuro text-white px-5 py-4 shadow-flota active:scale-[0.99] transition">
              <div className="flex items-center gap-3">
                <span className="grid place-items-center w-9 h-9 rounded-xl bg-white/15 font-bold">
                  {totalArticulos}
                </span>
                <span className="font-semibold">Ver mi bolsa</span>
              </div>
              <span className="font-display font-bold text-lg">
                {moneda(totalPrecio)} →
              </span>
            </div>
          </div>
        </Link>
      )}
    </section>
  );
}
