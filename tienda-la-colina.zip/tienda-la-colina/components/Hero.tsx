export default function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="mx-auto max-w-5xl px-4 pt-6 pb-2">
        <div className="relative rounded-3xl bg-verde text-white px-6 py-8 sm:px-10 sm:py-12 shadow-flota overflow-hidden">
          {/* Decoración */}
          <div className="absolute -right-10 -top-10 w-44 h-44 rounded-full bg-verde-claro/30 blur-2xl" />
          <div className="absolute -right-4 -bottom-12 w-56 h-56 rounded-full bg-naranja/20 blur-3xl" />

          <div className="relative animate-subir">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-sm font-semibold backdrop-blur">
              <span className="w-2 h-2 rounded-full bg-naranja-claro animate-pulso" />
              Tienda abierta · entregando ahora
            </span>

            <h1 className="mt-4 font-display font-extrabold leading-[1.05] text-3xl sm:text-5xl max-w-xl">
              ¿Te faltó algo? Te lo llevamos a tu puerta en{" "}
              <span className="text-naranja-claro">5 minutos.</span>
            </h1>

            <p className="mt-3 text-base sm:text-lg text-white/90 font-medium">
              Paga al recibir. Sin complicaciones, sin esperas.
            </p>

            <div className="mt-6 flex flex-wrap gap-3 text-sm">
              <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-2 font-semibold backdrop-blur">
                ⚡ Entrega en 5 min
              </span>
              <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-2 font-semibold backdrop-blur">
                💵 Pago contra entrega
              </span>
              <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-2 font-semibold backdrop-blur">
                📍 Solo tu fraccionamiento
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
