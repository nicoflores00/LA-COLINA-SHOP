"use client";

import { Producto, moneda } from "@/lib/productos";
import { useCarrito } from "@/context/CartContext";

export default function ProductCard({ producto }: { producto: Producto }) {
  const { items, agregar, cambiarCantidad } = useCarrito();
  const enCarrito = items.find((i) => i.id === producto.id);

  return (
    <div className="group flex flex-col rounded-2xl bg-white p-3 shadow-suave hover:shadow-flota transition-shadow">
      <div className="relative aspect-square rounded-xl bg-crema grid place-items-center text-5xl sm:text-6xl">
        <span className="transition-transform group-hover:scale-110">
          {producto.emoji}
        </span>
      </div>

      <div className="mt-3 flex-1">
        <h3 className="font-semibold text-sm leading-snug text-tinta line-clamp-2">
          {producto.nombre}
        </h3>
        <p className="mt-1 font-display font-bold text-verde text-lg">
          {moneda(producto.precio)}
          <span className="text-xs font-medium text-tinta/50 ml-1">
            /{producto.unidad}
          </span>
        </p>
      </div>

      {!enCarrito ? (
        <button
          onClick={() => agregar(producto)}
          className="mt-2 w-full rounded-xl bg-verde py-2.5 font-semibold text-white text-sm active:scale-95 transition hover:bg-verde-oscuro"
        >
          Agregar +
        </button>
      ) : (
        <div className="mt-2 flex items-center justify-between rounded-xl bg-verde px-2 py-1.5">
          <button
            onClick={() => cambiarCantidad(producto.id, enCarrito.cantidad - 1)}
            className="w-8 h-8 grid place-items-center rounded-lg bg-white/20 text-white text-lg font-bold active:scale-90 transition"
            aria-label="Quitar uno"
          >
            −
          </button>
          <span className="font-display font-bold text-white">
            {enCarrito.cantidad}
          </span>
          <button
            onClick={() => cambiarCantidad(producto.id, enCarrito.cantidad + 1)}
            className="w-8 h-8 grid place-items-center rounded-lg bg-white/20 text-white text-lg font-bold active:scale-90 transition"
            aria-label="Agregar uno"
          >
            +
          </button>
        </div>
      )}
    </div>
  );
}
