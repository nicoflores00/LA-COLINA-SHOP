export type Categoria =
  | "Despensa y Abarrotes"
  | "Lácteos, Huevos y Fríos"
  | "Bebidas y Hielo"
  | "Limpieza y Hogar";

export interface Producto {
  id: string;
  nombre: string;
  precio: number;
  categoria: Categoria;
  unidad: string;
  emoji: string;
}

export const CATEGORIAS: Categoria[] = [
  "Despensa y Abarrotes",
  "Lácteos, Huevos y Fríos",
  "Bebidas y Hielo",
  "Limpieza y Hogar",
];

// Mismos productos y precios que la tienda piloto en Vercel.
// El campo "emoji" es un placeholder ligero; puedes cambiarlo por
// fotos reales más adelante sin tocar el resto del código.
export const PRODUCTOS: Producto[] = [
  { id: "aceite-nutrioli", nombre: "Aceite Nutrioli de soya", precio: 30, categoria: "Despensa y Abarrotes", unidad: "pieza", emoji: "🫗" },
  { id: "azucar", nombre: "Azúcar", precio: 26, categoria: "Despensa y Abarrotes", unidad: "pieza", emoji: "🍬" },
  { id: "bolsa-hielos", nombre: "Bolsa de Hielos", precio: 25, categoria: "Bebidas y Hielo", unidad: "pieza", emoji: "🧊" },
  { id: "bolsas-basura", nombre: "Bolsas de Basura", precio: 40, categoria: "Limpieza y Hogar", unidad: "pieza", emoji: "🗑️" },
  { id: "catsup-heinz", nombre: "Catsup Heinz", precio: 40, categoria: "Despensa y Abarrotes", unidad: "pieza", emoji: "🍅" },
  { id: "coca-cola", nombre: "Coca Cola", precio: 50, categoria: "Bebidas y Hielo", unidad: "pieza", emoji: "🥤" },
  { id: "consome-knorr", nombre: "Consomé de pollo Knorr Suiza", precio: 18, categoria: "Despensa y Abarrotes", unidad: "pieza", emoji: "🍲" },
  { id: "crema-alpura", nombre: "Crema Alpura", precio: 24, categoria: "Lácteos, Huevos y Fríos", unidad: "pieza", emoji: "🥛" },
  { id: "huevos-san-juan", nombre: "Huevos San Juan", precio: 42, categoria: "Lácteos, Huevos y Fríos", unidad: "pieza", emoji: "🥚" },
  { id: "jabon-salvo", nombre: "Jabón de Trastes Salvo", precio: 28, categoria: "Limpieza y Hogar", unidad: "pieza", emoji: "🧽" },
  { id: "jamon-fud", nombre: "Jamón Virginia Fud", precio: 50, categoria: "Lácteos, Huevos y Fríos", unidad: "pieza", emoji: "🍖" },
  { id: "leche-deslactosada", nombre: "Leche Deslactosada", precio: 35, categoria: "Lácteos, Huevos y Fríos", unidad: "pieza", emoji: "🥛" },
  { id: "mayonesa-mccormick", nombre: "Mayonesa McCormick con jugo de limones", precio: 48, categoria: "Despensa y Abarrotes", unidad: "pieza", emoji: "🫙" },
  { id: "nescafe-clasico", nombre: "Nescafé Clásico", precio: 28, categoria: "Despensa y Abarrotes", unidad: "pieza", emoji: "☕" },
  { id: "pan-bimbo", nombre: "Pan Blanco Bimbo", precio: 45, categoria: "Despensa y Abarrotes", unidad: "pieza", emoji: "🍞" },
  { id: "sal-la-fina", nombre: "Sal La Fina", precio: 20, categoria: "Despensa y Abarrotes", unidad: "pieza", emoji: "🧂" },
  { id: "tortillinas-tia-rosa", nombre: "Tortillinas Tía Rosa", precio: 30, categoria: "Despensa y Abarrotes", unidad: "pieza", emoji: "🌮" },
];

export const moneda = (n: number) =>
  new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(n);
