import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

interface Articulo {
  nombre: string;
  sku: string;
  cantidad: number;
  precio: number;
}

interface Pedido {
  casa: string;
  telefono: string;
  pago: "efectivo" | "transferencia";
  total: number;
  articulos: Articulo[];
}

const moneda = (n: number) =>
  new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(n);

export async function POST(req: NextRequest) {
  let pedido: Pedido;
  try {
    pedido = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON inválido" }, { status: 400 });
  }

  // Validación mínima en el servidor (no confiar solo en el cliente)
  if (
    !pedido.casa?.trim() ||
    !pedido.telefono?.trim() ||
    !Array.isArray(pedido.articulos) ||
    pedido.articulos.length === 0
  ) {
    return NextResponse.json({ error: "Pedido incompleto" }, { status: 400 });
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.error("Faltan TELEGRAM_BOT_TOKEN o TELEGRAM_CHAT_ID");
    return NextResponse.json(
      { error: "Notificaciones no configuradas en el servidor" },
      { status: 500 }
    );
  }

  // Lista de artículos -> "• 2x Coca Cola (coca-cola) — $100.00"
  const lista = pedido.articulos
    .map(
      (a) =>
        `• ${a.cantidad}x ${a.nombre} (${a.sku}) — ${moneda(a.precio * a.cantidad)}`
    )
    .join("\n");

  const pagoTexto =
    pedido.pago === "efectivo"
      ? "Efectivo o transferencia al recibir"
      : "Transferencia al recibir";

  // Formato del mensaje de recepción (HTML de Telegram)
  const mensaje = [
    "🚨 <b>NUEVO PEDIDO - URGENTE</b> 🚨",
    "",
    `🏠 <b>Casa/Calle:</b> ${esc(pedido.casa)}`,
    `📱 <b>Teléfono:</b> ${esc(pedido.telefono)}`,
    "",
    "🛍️ <b>Artículos:</b>",
    esc(lista),
    "",
    `💰 <b>Total a cobrar:</b> ${moneda(pedido.total)}`,
    `💵 <b>Pago:</b> ${pagoTexto}`,
    "",
    `🕒 ${new Date().toLocaleString("es-MX", {
      timeZone: "America/Mexico_City",
      hour: "2-digit",
      minute: "2-digit",
    })}`,
  ].join("\n");

  try {
    const tgRes = await fetch(
      `https://api.telegram.org/bot${token}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text: mensaje,
          parse_mode: "HTML",
          disable_web_page_preview: true,
        }),
      }
    );

    if (!tgRes.ok) {
      const detalle = await tgRes.text();
      console.error("Error de Telegram:", detalle);
      return NextResponse.json(
        { error: "No se pudo notificar al operador" },
        { status: 502 }
      );
    }

    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("Fallo al contactar Telegram:", e);
    return NextResponse.json(
      { error: "Error de red al notificar" },
      { status: 502 }
    );
  }
}

// Escapar caracteres especiales de HTML para evitar romper el formato
function esc(t: string) {
  return t
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}
