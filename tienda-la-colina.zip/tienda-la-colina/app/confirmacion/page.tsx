"use client";

import Link from "next/link";

export default function ConfirmacionPage() {
  const numero = process.env.NEXT_PUBLIC_WHATSAPP_TIENDA || "";
  const mensaje = encodeURIComponent(
    "¡Hola! Acabo de hacer un pedido en La Colina y quiero agregar algo más 🙌"
  );
  const waLink = numero ? `https://wa.me/${numero}?text=${mensaje}` : "#";

  return (
    <div className="mx-auto max-w-md px-4 pt-16 text-center">
      <div className="relative inline-grid place-items-center">
        <div className="absolute inset-0 rounded-full bg-verde/20 blur-2xl" />
        <div className="relative grid place-items-center w-24 h-24 rounded-full bg-verde text-white text-5xl animate-subir">
          ✓
        </div>
      </div>

      <h1 className="mt-6 font-display font-extrabold text-3xl text-verde-oscuro leading-tight">
        ¡Pedido recibido!
      </h1>

      <p className="mt-3 text-tinta/70 text-lg">
        Tu vecino ya está armando tu bolsa. Llegamos en{" "}
        <span className="font-bold text-verde">menos de 5 minutos.</span>
      </p>

      <div className="mt-4 inline-flex items-center gap-2 rounded-full bg-naranja/10 text-naranja px-4 py-2 font-semibold">
        💵 Ten listo tu pago
      </div>

      <div className="mt-8 space-y-3">
        <a
          href={waLink}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-2 w-full rounded-xl bg-[#25D366] py-3.5 font-bold text-white active:scale-95 transition shadow-suave"
        >
          <span className="text-xl">💬</span>
          Contactar por WhatsApp a la Tienda
        </a>
        <p className="text-xs text-tinta/50">
          ¿Se te olvidó algo? Escríbenos antes de que salgamos.
        </p>

        <Link
          href="/"
          className="block w-full rounded-xl bg-white py-3.5 font-semibold text-verde shadow-suave active:scale-95 transition"
        >
          Volver a la tienda
        </Link>
      </div>
    </div>
  );
}
