"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCarrito } from "@/context/CartContext";
import { moneda } from "@/lib/productos";

export default function CarritoPage() {
  const { items, cambiarCantidad, quitar, totalPrecio, totalArticulos } = useCarrito();
  const router = useRouter();

  if (totalArticulos === 0) {
    return (
      <div className="mx-auto max-w-md px-4 pt-20 text-center">
        <div className="text-6xl">🛒</div>
        <h1 className="mt-4 font-display font-extrabold text-2xl text-verde-oscuro">
          Tu bolsa está vacía
        </h1>
        <p className="mt-2 text-tinta/60">
          Agrega lo que te faltó y te lo llevamos en 5 minutos.
        </p>
        <Link
          href="/"
          className="mt-6 inline-block rounded-xl bg-verde px-6 py-3 font-semibold text-white active:scale-95 transition"
        >
          Ver productos
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 pt-6">
      <h1 className="font-display font-extrabold text-2xl text-verde-oscuro">
        Tu bolsa
      </h1>

      <div className="mt-4 space-y-3">
        {items.map((i) => (
          <div
            key={i.id}
            className="flex items-center gap-3 rounded-2xl bg-white p-3 shadow-suave"
          >
            <div className="grid place-items-center w-14 h-14 rounded-xl bg-crema text-3xl shrink-0">
              {i.emoji}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm leading-snug line-clamp-2">
                {i.nombre}
              </p>
              <p className="text-verde font-display font-bold">
                {moneda(i.precio * i.cantidad)}
              </p>
            </div>
            <div className="flex items-center gap-2 rounded-xl bg-crema px-1.5 py-1">
              <button
                onClick={() => cambiarCantidad(i.id, i.cantidad - 1)}
                className="w-7 h-7 grid place-items-center rounded-lg bg-white text-lg font-bold active:scale-90"
                aria-label="Quitar uno"
              >
                −
              </button>
              <span className="font-bold w-5 text-center">{i.cantidad}</span>
              <button
                onClick={() => cambiarCantidad(i.id, i.cantidad + 1)}
                className="w-7 h-7 grid place-items-center rounded-lg bg-white text-lg font-bold active:scale-90"
                aria-label="Agregar uno"
              >
                +
              </button>
            </div>
            <button
              onClick={() => quitar(i.id)}
              className="text-tinta/30 hover:text-naranja text-lg px-1"
              aria-label="Eliminar"
            >
              ✕
            </button>
          </div>
        ))}
      </div>

      <div className="mt-6 rounded-2xl bg-white p-4 shadow-suave">
        <div className="flex items-center justify-between text-lg">
          <span className="font-semibold">Total</span>
          <span className="font-display font-extrabold text-verde-oscuro text-2xl">
            {moneda(totalPrecio)}
          </span>
        </div>
        <p className="mt-1 text-sm text-tinta/50">Pagas al recibir en tu puerta.</p>

        <button
          onClick={() => router.push("/checkout")}
          className="mt-4 w-full rounded-xl bg-verde py-3.5 font-semibold text-white active:scale-95 transition hover:bg-verde-oscuro"
        >
          Continuar al pedido →
        </button>
        <Link
          href="/"
          className="mt-2 block text-center text-sm font-semibold text-verde"
        >
          Seguir agregando
        </Link>
      </div>
    </div>
  );
}
