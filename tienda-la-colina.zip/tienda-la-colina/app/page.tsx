import Hero from "@/components/Hero";
import Catalogo from "@/components/Catalogo";

export default function Home() {
  return (
    <div className="fondo-textura">
      <Hero />
      <Catalogo />
    </div>
  );
}
