"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCarrito } from "@/context/CartContext";
import { moneda } from "@/lib/productos";

export default function CheckoutPage() {
  const { items, totalPrecio, totalArticulos, vaciar } = useCarrito();
  const router = useRouter();

  const [casa, setCasa] = useState("");
  const [telefono, setTelefono] = useState("");
  const [pago, setPago] = useState<"efectivo" | "transferencia">("efectivo");
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState("");

  if (totalArticulos === 0 && !enviando) {
    if (typeof window !== "undefined") router.replace("/");
    return null;
  }

  const enviarPedido = async () => {
    setError("");
    if (!casa.trim()) return setError("Escribe tu número de casa o calle.");
    if (telefono.replace(/\D/g, "").length < 10)
      return setError("Escribe un WhatsApp válido (10 dígitos).");

    setEnviando(true);
    try {
      const res = await fetch("/api/pedido", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          casa: casa.trim(),
          telefono: telefono.trim(),
          pago,
          total: totalPrecio,
          articulos: items.map((i) => ({
            nombre: i.nombre,
            sku: i.id,
            cantidad: i.cantidad,
            precio: i.precio,
          })),
        }),
      });

      if (!res.ok) throw new Error("No se pudo enviar el pedido");

      vaciar();
      router.push("/confirmacion");
    } catch (e) {
      setEnviando(false);
      setError(
        "Hubo un problema al enviar. Revisa tu conexión e intenta de nuevo."
      );
    }
  };

  return (
    <div className="mx-auto max-w-lg px-4 pt-6">
      <h1 className="font-display font-extrabold text-2xl text-verde-oscuro">
        Casi listo 🚀
      </h1>
      <p className="mt-1 text-tinta/60 text-sm">
        Solo necesitamos saber a dónde llegar.
      </p>

      <div className="mt-6 space-y-4">
        {/* Dirección dentro del fraccionamiento */}
        <div className="rounded-2xl bg-white p-4 shadow-suave">
          <label className="block text-sm font-semibold text-tinta">
            🏠 Número de casa y/o calle
          </label>
          <input
            value={casa}
            onChange={(e) => setCasa(e.target.value)}
            placeholder="Ej. Casa 24, Calle Roble"
            className="mt-2 w-full rounded-xl border border-verde/15 bg-crema px-4 py-3 outline-none focus:border-verde focus:ring-2 focus:ring-verde/20"
            autoComplete="off"
          />
        </div>

        {/* WhatsApp */}
        <div className="rounded-2xl bg-white p-4 shadow-suave">
          <label className="block text-sm font-semibold text-tinta">
            📱 WhatsApp / Teléfono
          </label>
          <input
            value={telefono}
            onChange={(e) => setTelefono(e.target.value)}
            placeholder="961 123 4567"
            inputMode="tel"
            className="mt-2 w-full rounded-xl border border-verde/15 bg-crema px-4 py-3 outline-none focus:border-verde focus:ring-2 focus:ring-verde/20"
          />
          <p className="mt-1.5 text-xs text-tinta/50">
            Por si necesitamos confirmar algo de tu pedido.
          </p>
        </div>

        {/* Método de pago */}
        <div className="rounded-2xl bg-white p-4 shadow-suave">
          <p className="text-sm font-semibold text-tinta mb-3">
            💵 Método de pago
          </p>

          <button
            onClick={() => setPago("efectivo")}
            className={`w-full text-left rounded-xl border-2 p-3 transition ${
              pago === "efectivo"
                ? "border-verde bg-verde/5"
                : "border-transparent bg-crema"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-semibold">Pago a contra-entrega</span>
              <span className="text-verde">
                {pago === "efectivo" ? "●" : "○"}
              </span>
            </div>
            <p className="text-xs text-tinta/60 mt-1">
              Paga en efectivo o realiza la transferencia al momento de recibir
              tus productos en la puerta.
            </p>
          </button>
        </div>

        {error && (
          <p className="rounded-xl bg-naranja/10 text-naranja px-4 py-3 text-sm font-medium">
            {error}
          </p>
        )}

        {/* Resumen + confirmar */}
        <div className="rounded-2xl bg-verde-oscuro text-white p-4 shadow-flota">
          <div className="flex items-center justify-between">
            <span className="text-white/80">
              {totalArticulos} artículo{totalArticulos !== 1 && "s"}
            </span>
            <span className="font-display font-extrabold text-2xl">
              {moneda(totalPrecio)}
            </span>
          </div>
          <button
            onClick={enviarPedido}
            disabled={enviando}
            className="mt-3 w-full rounded-xl bg-naranja py-3.5 font-bold text-white active:scale-95 transition hover:bg-naranja-claro disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {enviando ? "Enviando pedido…" : "Confirmar pedido ✓"}
          </button>
        </div>
      </div>
    </div>
  );
}
