"use client";

import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { Producto } from "@/lib/productos";

export interface ItemCarrito extends Producto {
  cantidad: number;
}

interface CartCtx {
  items: ItemCarrito[];
  agregar: (p: Producto) => void;
  quitar: (id: string) => void;
  cambiarCantidad: (id: string, cantidad: number) => void;
  vaciar: () => void;
  totalArticulos: number;
  totalPrecio: number;
}

const Ctx = createContext<CartCtx | null>(null);
const KEY = "carrito-la-colina";

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ItemCarrito[]>([]);
  const [listo, setListo] = useState(false);

  // Cargar carrito guardado al iniciar
  useEffect(() => {
    try {
      const guardado = localStorage.getItem(KEY);
      if (guardado) setItems(JSON.parse(guardado));
    } catch {}
    setListo(true);
  }, []);

  // Guardar cada cambio
  useEffect(() => {
    if (listo) localStorage.setItem(KEY, JSON.stringify(items));
  }, [items, listo]);

  const agregar = (p: Producto) =>
    setItems((prev) => {
      const existe = prev.find((i) => i.id === p.id);
      if (existe)
        return prev.map((i) =>
          i.id === p.id ? { ...i, cantidad: i.cantidad + 1 } : i
        );
      return [...prev, { ...p, cantidad: 1 }];
    });

  const quitar = (id: string) =>
    setItems((prev) => prev.filter((i) => i.id !== id));

  const cambiarCantidad = (id: string, cantidad: number) =>
    setItems((prev) =>
      cantidad <= 0
        ? prev.filter((i) => i.id !== id)
        : prev.map((i) => (i.id === id ? { ...i, cantidad } : i))
    );

  const vaciar = () => setItems([]);

  const totalArticulos = items.reduce((s, i) => s + i.cantidad, 0);
  const totalPrecio = items.reduce((s, i) => s + i.precio * i.cantidad, 0);

  return (
    <Ctx.Provider
      value={{ items, agregar, quitar, cambiarCantidad, vaciar, totalArticulos, totalPrecio }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useCarrito() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useCarrito debe usarse dentro de CartProvider");
  return ctx;
}
